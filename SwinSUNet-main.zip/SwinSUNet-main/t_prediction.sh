python CD_prediction.py -sp='./save/' -p='/home/zc/ChangeDetectionDataset/Real/subset/test/' -gid=4 -bs=1 -model_name='swin_result/net-best_epoch-74_fm-0.9391309866643824.pth.tar'

#'/home/zc/Building_change_detection_dataset_add/BCDD224/