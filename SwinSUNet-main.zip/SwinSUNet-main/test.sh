python CD_test.py -p='/home/zc/ChangeDetectionDataset/Real/subset/' -gid=4 -bs=12 -model_name='swin_result6/net-best_epoch-144_fm-0.9387250669289654.pth.tar'

#'/home/zc/Building_change_detection_dataset_add/BCDD224/