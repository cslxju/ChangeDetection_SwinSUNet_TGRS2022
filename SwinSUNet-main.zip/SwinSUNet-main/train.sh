python CD_train.py -p='/home/zc/ChangeDetectionDataset/Real/subset/' -gid=1 -bs=24

#'/home/zc/Building_change_detection_dataset_add/BCDD224/